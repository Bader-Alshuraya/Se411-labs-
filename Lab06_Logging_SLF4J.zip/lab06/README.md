# SE411 Lab 06 — Logging with SLF4J

Complete solution based on the supplied starter project. Uses SLF4J 2.0.16 and configurable logging implementations.

## Run

Requires Java 17+ and Maven. From this directory:

```bash
mvn clean package exec:java
```

The default `log4j` profile writes logs to `logs/App/log4j/log.out`. Create the folder first if needed (`mkdir -p logs/App/log4j` on macOS/Linux; `mkdir logs\App\log4j` on Windows). The configuration currently uses INFO so startup/shutdown and WARN/ERROR events appear. To demonstrate the exercise's initial ERROR-only stage, change `log4j.rootLogger=INFO, LOG1` to `log4j.rootLogger=ERROR, LOG1` in `src/main/resources/log4j.properties`; to show deposits and withdrawals change it to DEBUG. **Important:** This file-based logger does not print to the terminal; inspect the log file.

### Three stages requested by the lab

- **SLF4J API only:** `mvn -Papi-only clean package exec:java` — demonstrates the missing-provider warning.
- **Logback:** `mvn -Plogback clean package exec:java` — prints logs to the terminal using `logback.xml`.
- **Log4j-compatible backend:** `mvn -Plog4j clean package exec:java` — writes the file using `log4j.properties`.

The worksheet names `slf4j-log4j12` version 2.0.16; for SLF4J 2.x the supported replacement is `slf4j-reload4j` (the legacy coordinate is relocated). It uses the same `log4j.properties` syntax.

## Implemented logging strategy

| Event | Level |
|---|---|
| Application starts / ends | INFO |
| Wallet created | DEBUG |
| Successful deposit / withdrawal | DEBUG |
| InsufficientFundsException constructed | WARN |
| Exceptions caught by App | ERROR |

## Review of logging strategy (AI-assisted, not a GitHub Copilot run)

- Parameterized SLF4J messages avoid eager formatting.
- Keep successful operations at DEBUG to reduce noise in production.
- Exceptions are logged at ERROR where handled, including stack traces.
- Use WARN when an insufficient-funds exception is created, as requested.
- Reject NaN and infinite amounts to avoid corrupting balances.
- Real payment systems should use `BigDecimal` instead of `double`; `double` is retained to preserve the starter lab's design.

The project does not include generated `target/` build files. GitHub stores the source, and Maven downloads dependencies when built.
