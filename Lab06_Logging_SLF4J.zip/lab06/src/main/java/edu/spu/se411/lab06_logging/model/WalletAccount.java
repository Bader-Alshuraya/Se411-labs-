package edu.spu.se411.lab06_logging.model;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import edu.spu.se411.lab06_logging.exceptions.InsufficientFundsException;

public class WalletAccount {
    private static final Logger logger = LoggerFactory.getLogger(WalletAccount.class);
    private double balance;

    public WalletAccount(double balance) {
        setBalance(balance);
        logger.debug("Wallet account created with balance {}", balance);
    }

    public void withdraw(double amount) throws InsufficientFundsException {
        if (!Double.isFinite(amount) || amount < 0) {
            throw new IllegalArgumentException("Invalid withdrawal amount: " + amount);
        }
        if (amount > balance) {
            throw new InsufficientFundsException("Insufficient funds. Your balance is " + balance);
        }
        balance -= amount;
        logger.debug("Withdrawal of {} completed; remaining balance {}", amount, balance);
    }

    public void deposit(double amount) {
        if (!Double.isFinite(amount) || amount < 0) {
            throw new IllegalArgumentException("Invalid deposit amount: " + amount);
        }
        balance += amount;
        logger.debug("Deposit of {} completed; new balance {}", amount, balance);
    }

    public void setBalance(double balance) {
        if (!Double.isFinite(balance) || balance < 0) {
            throw new IllegalArgumentException("Invalid balance: " + balance);
        }
        this.balance = balance;
    }

    public double getBalance() { return balance; }
}
