package edu.psu.se411;

import edu.psu.se411.exceptions.InvalidAgeException;
import edu.psu.se411.exceptions.InsufficientFundsException;
import java.math.BigDecimal;

public class App {
    public static void validateAge(int age) throws InvalidAgeException {
        if (age < 18) throw new InvalidAgeException("Age " + age + " is below the minimum of 18.");
        System.out.println("Age valid message.");
    }

    public static void main(String[] args) {
        System.out.println("Exercise 1: Custom Exceptions");
        for (int age : new int[]{21, 16, 18}) {
            try { validateAge(age); }
            catch (InvalidAgeException e) { System.out.println("Invalid age: " + e.getMessage()); }
        }

        System.out.println("\nExercise 2: Online Wallet");
        Wallet wallet = new Wallet(new BigDecimal("500.00"));
        BankAccount bank = new BankAccount(new BigDecimal("100.00"));
        try {
            wallet.withdrawToBank(bank, new BigDecimal("150.00"));
            System.out.println("Transferred 150.00 to bank successfully.");
            wallet.withdrawToBank(bank, new BigDecimal("400.00"));
        } catch (InsufficientFundsException e) {
            System.out.println("Withdrawal failed: " + e.getMessage());
        }
        System.out.println("Wallet balance: " + wallet.getBalance());
        System.out.println("Bank balance: " + bank.getBalance());
    }
}
