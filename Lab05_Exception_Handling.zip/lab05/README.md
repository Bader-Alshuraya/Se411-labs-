# SE411 Lab 05 — Exception Handling

## Exercise 1: Custom Exceptions
- `InvalidAgeException` lives in the dedicated `exceptions` package.
- `App.validateAge(int)` throws the custom exception for ages below 18 and prints `Age valid message.` otherwise.

## Exercise 2: Online Wallet
- `Wallet.withdrawToBank()` transfers money into a `BankAccount`.
- `InsufficientFundsException` is thrown if the withdrawal exceeds the wallet balance.
- Invalid or null amounts are rejected separately with standard Java exceptions.
- `BigDecimal` avoids floating-point rounding errors for monetary values.

## Run
Requires JDK 17+ and Maven. From this directory:

```sh
mvn clean package
mvn exec:java
```

Or use `mvn clean package exec:java`.

## Example output
```
Exercise 1: Custom Exceptions
Age valid message.
Invalid age: Age 16 is below the minimum of 18.
Age valid message.

Exercise 2: Online Wallet
Transferred 150.00 to bank successfully.
Withdrawal failed: Insufficient funds: wallet has 350.00, requested 400.00
Wallet balance: 350.00
Bank balance: 250.00
```

## Exception-handling review (manual checklist)
- Custom exceptions have meaningful names and messages.
- Checked exceptions are caught where recovery or user feedback is possible.
- Balance remains unchanged when a withdrawal fails.
- Null and nonpositive inputs are rejected.
- Monetary values use `BigDecimal`.

**Assignment note:** The instructions ask for a GitHub Copilot review. This checklist is not a Copilot review; run Copilot separately if evidence of its review is required.
