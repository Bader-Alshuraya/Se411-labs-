INSERT INTO course(code,name,description,credits)
 SELECT 'CS101','Programming 1','An introduction to programming',3
 WHERE NOT EXISTS (SELECT 1 FROM course WHERE code='CS101');
INSERT INTO course(code,name,description,credits)
 SELECT 'CS102','Programming 2','Object oriented programming course',3
 WHERE NOT EXISTS (SELECT 1 FROM course WHERE code='CS102');
