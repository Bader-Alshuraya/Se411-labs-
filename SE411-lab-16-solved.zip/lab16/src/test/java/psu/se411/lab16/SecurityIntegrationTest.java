package psu.se411.lab16;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.*;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestBuilders.formLogin;
import static org.springframework.security.test.web.servlet.response.SecurityMockMvcResultMatchers.*;
@SpringBootTest @AutoConfigureMockMvc @ActiveProfiles("test")
class SecurityIntegrationTest {
 @Autowired MockMvc mvc;
 @Test void publicHomeAndLoginAndPrivateRoutes() throws Exception {
  mvc.perform(get("/")).andExpect(status().isOk());
  mvc.perform(get("/login")).andExpect(status().isOk()).andExpect(content().string(org.hamcrest.Matchers.containsString("_csrf")));
  mvc.perform(get("/api/v1/courses")).andExpect(status().is3xxRedirection());
 }
 @Test void realFormLoginAndRoleRestrictions() throws Exception {
  var result=mvc.perform(formLogin().user("usera").password("pwd123"))
   .andExpect(authenticated().withUsername("usera")).andReturn();
  MockHttpSession session=(MockHttpSession)result.getRequest().getSession(false);
  mvc.perform(get("/dashboard").session(session)).andExpect(status().isOk());
  mvc.perform(get("/admindashboard").session(session)).andExpect(status().isForbidden());
  var admin=mvc.perform(formLogin().user("admin").password("admin123"))
   .andExpect(authenticated().withUsername("admin")).andReturn();
  var adminSession=(MockHttpSession)admin.getRequest().getSession(false);
  mvc.perform(get("/admindashboard").session(adminSession)).andExpect(status().isOk());
  mvc.perform(get("/dashboard").session(adminSession)).andExpect(status().isForbidden());
  mvc.perform(post("/logout").session(session).with(csrf())).andExpect(status().is3xxRedirection()).andExpect(unauthenticated());
 }
 @Test void loginRejectsWrongPasswordAndMissingCsrf() throws Exception {
  mvc.perform(formLogin().user("usera").password("wrong")).andExpect(unauthenticated());
  mvc.perform(post("/login").param("username","usera").param("password","pwd123")).andExpect(status().isForbidden());
 }
 @Test void courseCrudRequiresCsrfAndReturnsCorrectLocation() throws Exception {
  mvc.perform(post("/api/v1/courses").with(user("usera")).contentType("application/json")
   .content("{\"code\":\"SE411\",\"name\":\"Web\",\"credits\":3}" )).andExpect(status().isForbidden());
  String location=mvc.perform(post("/api/v1/courses").with(user("usera")).with(csrf()).contentType("application/json")
   .content("{\"code\":\"SE411\",\"name\":\"Web\",\"credits\":3}" )).andExpect(status().isCreated())
   .andReturn().getResponse().getHeader("Location");
  org.junit.jupiter.api.Assertions.assertNotNull(location);
  mvc.perform(get(location).with(user("usera"))).andExpect(status().isOk()).andExpect(jsonPath("$.code").value("SE411"));
  mvc.perform(get("/api/v1/courses").with(user("usera"))).andExpect(status().isOk());
  mvc.perform(put(location).with(user("usera")).with(csrf()).contentType("application/json")
   .content("{\"code\":\"SE411\",\"name\":\"Updated\",\"credits\":4}" )).andExpect(status().isNoContent());
  mvc.perform(get(location).with(user("usera"))).andExpect(jsonPath("$.credits").value(4));
  mvc.perform(delete(location).with(user("usera")).with(csrf())).andExpect(status().isNoContent());
  mvc.perform(get(location).with(user("usera"))).andExpect(status().isNotFound());
 }
}
