package psu.se411.lab16;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@org.springframework.test.context.ActiveProfiles("test")
@SpringBootTest
class CrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
