# Lab 16 solution

See the parent README for JDK, MySQL configuration and test commands. Use your own MySQL connection and an empty database named `se411_lab16`. The default port is 8080.

Form login: `usera / pwd123` (USER) and `admin / admin123` (ADMIN). Only USER can access `/dashboard`; only ADMIN can access `/admindashboard`. Login and every state-changing request require the current session CSRF token. Logout is POST `/logout` with CSRF.

The demo credentials are for this exercise. Seeded database passwords are BCrypt hashes. 

API collection: `requests.postman_collection.json`.
Course endpoints: `/api/v1/courses` and `/api/v1/courses/{id}`.

CRUD responses: list/get = 200; create = 201 with the saved resource ID in Location; update/delete = 204; missing IDs = 404. 

Run `.\mvnw.cmd test` to execute the isolated H2 tests. These exercise application behavior without needing Aiven. A live MySQL/Aiven check still requires your actual database connection.
