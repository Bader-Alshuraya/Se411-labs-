package edu.psu.se411.lab07;

import java.time.LocalDate;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class App {
    private static final Logger logger = LoggerFactory.getLogger(App.class);
    public static double computeTotalPrice(Booking booking) throws MissingInformationException, InvalidArgumentException {
        return booking.calculateTotalPrice();
    }
    public static void main(String[] args) {
        logger.info("Application is starting...");
        try {
            LocalDate date = LocalDate.of(2026, 11, 1);
            FlightBooking flight = new FlightBooking("F001", "Sara Ahmed", date, "Dubai", 500);
            TrainBooking train = new TrainBooking("T001", "Omar Ali", date, "Jeddah", TrainBooking.SeatClass.FIRST_CLASS);
            CarRentalBooking car = new CarRentalBooking("C001", "Nora Saleh", date, "Riyadh", 120);
            flight.setLuggageWeight(12);
            train.setDistanceKm(900);
            car.setRentalDays(4);
            for (Booking booking : List.of(flight, train, car)) {
                System.out.printf("%s (%s): %.2f SAR%n", booking.getBookingId(), booking.getClass().getSimpleName(), computeTotalPrice(booking));
            }
            // Demonstrate required exception handling and file logging.
            try {
                computeTotalPrice(new FlightBooking("F002", "Test Customer", date, "Dammam", 200));
            } catch (MissingInformationException | InvalidArgumentException e) {
                logger.error("Expected missing-information exception", e);
                System.out.println("Handled expected exception: " + e.getMessage());
            }
            try {
                car.setRentalDays(31);
            } catch (InvalidArgumentException e) {
                logger.error("Expected invalid-argument exception", e);
                System.out.println("Handled expected exception: " + e.getMessage());
            }
        } catch (Exception e) {
            logger.error("Unexpected application failure", e);
        } finally {
            logger.info("Application is stopping...");
        }
    }
}
