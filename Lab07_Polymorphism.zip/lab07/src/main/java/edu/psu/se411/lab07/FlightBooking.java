package edu.psu.se411.lab07;

import java.time.LocalDate;

public class FlightBooking extends Booking {
    private final double baseTicketPrice;
    private Double luggageWeight;
    public FlightBooking(String id, String customer, LocalDate date, String destination, double baseTicketPrice) {
        super(id, customer, date, destination);
        if (!Double.isFinite(baseTicketPrice) || baseTicketPrice < 0) throw new IllegalArgumentException("Invalid ticket price");
        this.baseTicketPrice = baseTicketPrice;
    }
    public void setLuggageWeight(double weight) throws InvalidArgumentException {
        if (!Double.isFinite(weight) || weight < 0 || weight > Config.MAX_LUGGAGE_WEIGHT)
            throw new InvalidArgumentException("Luggage weight must be between 0 and 40 kg");
        this.luggageWeight = weight;
    }
    @Override public double calculateTotalPrice() throws MissingInformationException {
        if (luggageWeight == null) throw new MissingInformationException("Flight luggage weight has not been provided");
        return baseTicketPrice + luggageWeight * Config.EXTRA_LUGGAGE_RATE;
    }
}
