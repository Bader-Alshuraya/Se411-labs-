package edu.psu.se411.lab07;

import java.time.LocalDate;
import java.util.Objects;

public abstract class Booking {
    private final String bookingId;
    private final String customerFullName;
    private final LocalDate travelDate;
    private final String destinationCity;

    protected Booking(String bookingId, String customerFullName, LocalDate travelDate, String destinationCity) {
        if (bookingId == null || bookingId.isBlank() || customerFullName == null || customerFullName.isBlank()
                || destinationCity == null || destinationCity.isBlank() || travelDate == null) {
            throw new IllegalArgumentException("All booking details are required");
        }
        this.bookingId = bookingId;
        this.customerFullName = customerFullName;
        this.travelDate = travelDate;
        this.destinationCity = destinationCity;
    }
    public String getBookingId() { return bookingId; }
    public String getCustomerFullName() { return customerFullName; }
    public LocalDate getTravelDate() { return travelDate; }
    public String getDestinationCity() { return destinationCity; }
    public abstract double calculateTotalPrice() throws MissingInformationException, InvalidArgumentException;
}
