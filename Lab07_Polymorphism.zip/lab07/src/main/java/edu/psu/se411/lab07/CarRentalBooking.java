package edu.psu.se411.lab07;

import java.time.LocalDate;

public class CarRentalBooking extends Booking {
    private final double dailyRentalRate;
    private Integer rentalDays;
    public CarRentalBooking(String id, String customer, LocalDate date, String destination, double dailyRentalRate) {
        super(id, customer, date, destination);
        if (!Double.isFinite(dailyRentalRate) || dailyRentalRate < 0) throw new IllegalArgumentException("Invalid daily rate");
        this.dailyRentalRate = dailyRentalRate;
    }
    public void setRentalDays(int days) throws InvalidArgumentException {
        if (days < 1 || days > Config.MAX_RENTAL_DAYS)
            throw new InvalidArgumentException("Rental days must be between 1 and 30");
        this.rentalDays = days;
    }
    @Override public double calculateTotalPrice() throws MissingInformationException {
        if (rentalDays == null) throw new MissingInformationException("Rental days have not been provided");
        return dailyRentalRate * rentalDays;
    }
}
