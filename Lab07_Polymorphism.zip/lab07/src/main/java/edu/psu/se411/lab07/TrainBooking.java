package edu.psu.se411.lab07;

import java.time.LocalDate;

public class TrainBooking extends Booking {
    public enum SeatClass { STANDARD, FIRST_CLASS }
    private final SeatClass seatClass;
    private Double distanceKm;
    public TrainBooking(String id, String customer, LocalDate date, String destination, SeatClass seatClass) {
        super(id, customer, date, destination);
        if (seatClass == null) throw new IllegalArgumentException("Seat class is required");
        this.seatClass = seatClass;
    }
    public void setDistanceKm(double distance) throws InvalidArgumentException {
        if (!Double.isFinite(distance) || distance < 1 || distance > Config.MAX_TRAIN_DISTANCE)
            throw new InvalidArgumentException("Distance must be between 1 and 2000 km");
        this.distanceKm = distance;
    }
    @Override public double calculateTotalPrice() throws MissingInformationException {
        if (distanceKm == null) throw new MissingInformationException("Train distance has not been provided");
        return distanceKm * (seatClass == SeatClass.STANDARD ? Config.TRAIN_STANDARD_RATE : Config.TRAIN_FIRST_CLASS_RATE);
    }
}
