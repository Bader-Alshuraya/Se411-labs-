package edu.psu.se411.lab07;

public final class Config {
    private Config() {}
    public static final double EXTRA_LUGGAGE_RATE = 15.0;
    public static final double TRAIN_STANDARD_RATE = 0.50;
    public static final double TRAIN_FIRST_CLASS_RATE = 1.00;
    public static final double MAX_LUGGAGE_WEIGHT = 40.0;
    public static final double MAX_TRAIN_DISTANCE = 2000.0;
    public static final int MAX_RENTAL_DAYS = 30;
}
