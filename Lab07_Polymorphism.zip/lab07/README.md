# Lab 07 — Polymorphism in Java

SE411 travel-agency booking exercise. Three booking subclasses extend `Booking` and override `calculateTotalPrice()`. `App.computeTotalPrice(Booking)` demonstrates runtime polymorphism. Input validation uses custom checked exceptions, and SLF4J with reload4j (maintained Log4j 1.x-compatible backend) writes start/stop and exception events to `logs/App/log.out`.

## Run

Requires Java 17+ and Maven with internet access for dependencies.

```bash
mvn clean package exec:java
```

Expected sample prices: Flight F001 = 680.00 SAR, Train T001 = 900.00 SAR, Car C001 = 480.00 SAR. The main program also handles one missing-information exception and one invalid-argument exception; both are written to the log file.

## Rules

- Flight: base ticket price + luggage kg × 15 SAR; luggage must be 0–40 kg.
- Train: standard 0.50 SAR/km, first class 1.00 SAR/km; distance 1–2000 km.
- Car: daily rate × days; days 1–30.

Rates are illustrative since the assignment provides constant names but no numerical rates. Edit `Config.java` if your instructor specifies rates.

## Notes

The assignment names `slf4j-log4j12` version 2.0.16; this project uses `slf4j-reload4j` 2.0.16, the supported Log4j-1-compatible binding for SLF4J 2.x. It still uses the required `log4j.properties` format and writes to a file. Maven dependencies require downloading on first build. The project has not been Maven-executed in this environment.
