# SE411 Course Project

Welcome to the SE411 Lab 04 Maven site. This demonstration project uses **Java 21**, **JavaFX 23**, and **Maven**.

## Goals

- Configure JavaFX using Maven dependencies and a run plugin.
- Launch a simple graphical application with a button.
- Publish generated project documentation with the Maven Site Plugin.

## Exercises

**Exercise 1:** JavaFX Maven setup and graphical application.

**Exercise 2:** Project metadata, Apache 2.0 license declaration, and a documentation site.

**Before submission:** Replace the placeholder project name, team, GitHub URL, and developer name with your actual course-project details.
