# Running the Project

## Requirements

Install JDK 21 and Apache Maven 3.9+; the JavaFX dependencies are resolved by Maven.

## JavaFX desktop application

```bash
mvn clean javafx:run
```

A window titled **SE411 Course Project - Lab 04** appears. Click the button to change the status text.

## Generate the website

```bash
mvn clean site
```

Open `target/site/index.html` in a browser. Maven also generates project information pages.
