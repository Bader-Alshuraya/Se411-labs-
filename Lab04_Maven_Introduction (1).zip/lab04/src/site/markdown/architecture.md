# Architecture

The Maven project uses the standard directory layout:

- `pom.xml`: dependencies, plugins, and project metadata.
- `src/main/java/psu/se411/courseproject/Main.java`: JavaFX application entry point.
- `src/site/markdown/`: additional site content.
- `src/site/site.xml`: documentation navigation.

The JavaFX application extends `Application`, implements `start(Stage)`, and uses `launch(args)` in `main`.
