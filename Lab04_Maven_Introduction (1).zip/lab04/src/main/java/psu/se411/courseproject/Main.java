package psu.se411.courseproject;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Main extends Application {
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        Label heading = new Label("SE411 - Maven & JavaFX");
        Label message = new Label("Lab 04: JavaFX is working!");
        Button button = new Button("Click Me");
        button.setOnAction(event -> message.setText("Button clicked successfully!"));

        VBox layout = new VBox(16, heading, message, button);
        layout.setPadding(new Insets(24));
        layout.setAlignment(Pos.CENTER);
        Scene scene = new Scene(layout, 460, 240);
        primaryStage.setTitle("SE411 Course Project - Lab 04");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
