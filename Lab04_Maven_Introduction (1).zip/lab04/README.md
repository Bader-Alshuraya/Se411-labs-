# SE411 — Lab 04: Maven Introduction

This is a GitHub-ready Maven project for both exercises of the provided lab sheet.

## Exercise 1 — Maven Dependencies / JavaFX

- Standard Maven structure and package `psu.se411.courseproject`
- JavaFX controls version **23**
- JavaFX Maven plugin version **0.0.8**
- `Main` extends `Application`, creates a Stage and Scene, and displays a working button.

Run with **JDK 21** and **Maven 3.9+**:

```bash
mvn clean javafx:run
```

The desktop window needs a graphical environment. It cannot display on a headless GitHub server by merely uploading the source.

## Exercise 2 — Maven Site Plugin

`pom.xml` declares the project name, description, URL, Apache 2.0 license, organization, and developer. Custom documentation is in `src/site/markdown`.

```bash
mvn clean site
```

Open `target/site/index.html` after Maven generates it. The `target/` directory is generated output and is intentionally excluded from Git.

## Before submitting

The lab explicitly requests the name of your **actual course main project** and your **team/company namespace**. Because neither was supplied, this project uses placeholders. Replace:

1. `se411-course-project`, `SE411 Course Project`, and the package `psu.se411.courseproject` if your actual course project uses a different name.
2. The GitHub URL and organization URL placeholders in `pom.xml`.
3. `REPLACE WITH YOUR NAME` and the organization name in `pom.xml`.

The lab asks you to run Maven goals and observe the window and generated site. These actions still need to be performed on a machine with JDK, Maven, and (for JavaFX) a desktop display.

## Verification

The XML configuration was parsed for well-formedness. Maven itself was not installed in the packaging environment, so Maven dependency resolution, JavaFX runtime behavior, and generated site output were not verified here.
