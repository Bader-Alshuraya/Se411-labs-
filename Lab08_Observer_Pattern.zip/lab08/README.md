# Lab 08 – Advanced OO in Java: Observer Pattern

Complete Maven project for the SE411 Observer Pattern lab.

## Requirements
Java 17+ and Maven.

## Run
```bash
mvn clean package exec:java
```

The program registers DashboardObserver and LoggerObserver with temperature and humidity sensors, simulates 10 changes (one second apart), then demonstrates cloning and unregistering. Updates are printed to the console and recorded in `logs/App/log4j/log.out`.

## Classes
- `Subject` and `Observer`: interfaces specified in the assignment.
- `Sensor`: implements Subject and Cloneable; clone receives its own **empty** observer list.
- `DashboardObserver`: displays readings.
- `LoggerObserver`: prints and logs updates.
- `App`: demonstrates notifications, cloning, and unregistering.

**Note:** The handout lists `slf4j-log4j12:2.0.16`, which is not the correct SLF4J 2.x binding artifact. This project uses `slf4j-reload4j:2.0.16`, compatible with the handout's Log4j 1.x-style `log4j.properties` configuration.

Maven could not be run in the authoring environment; run the command above to verify dependency resolution and output.
