package edu.spu.se411.lab08;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
public class Sensor implements Subject, Cloneable {
 private final String name;
 private double reading;
 private List<Observer> observers = new ArrayList<>();
 public Sensor(String name, double initialReading) { this.name = Objects.requireNonNull(name); this.reading = initialReading; }
 public String getName() { return name; }
 public double getReading() { return reading; }
 public void setReading(double reading) {
  if (!Double.isFinite(reading)) throw new IllegalArgumentException("Reading must be finite");
  if (Double.compare(this.reading, reading) != 0) { this.reading = reading; notifyObservers(); }
 }
 @Override public void register(Observer o) { Objects.requireNonNull(o); if (!observers.contains(o)) observers.add(o); }
 @Override public void unregister(Observer o) { observers.remove(o); }
 @Override public void notifyObservers() { for (Observer o : new ArrayList<>(observers)) o.update(this); }
 @Override public Sensor clone() {
  try { Sensor copy = (Sensor) super.clone(); copy.observers = new ArrayList<>(); return copy; }
  catch (CloneNotSupportedException e) { throw new AssertionError(e); }
 }
}
