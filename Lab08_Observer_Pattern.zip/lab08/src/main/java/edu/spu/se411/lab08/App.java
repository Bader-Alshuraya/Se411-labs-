package edu.spu.se411.lab08;
import java.util.Random;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class App {
 private static final Logger logger = LoggerFactory.getLogger(App.class);
 public static void main(String[] args) {
  logger.info("Application starting");
  try {
   Sensor temp = new Sensor("Temperature (C)", 20);
   Sensor humidity = new Sensor("Humidity (%)", 40);
   Observer dashboard = new DashboardObserver();
   Observer sensorLogger = new LoggerObserver();
   temp.register(dashboard); temp.register(sensorLogger);
   humidity.register(dashboard); humidity.register(sensorLogger);
   Random random = new Random();
   for (int i = 0; i < 10; i++) {
    temp.setReading(20 + random.nextDouble() * 15);
    humidity.setReading(40 + random.nextDouble() * 20);
    try { Thread.sleep(1000); }
    catch (InterruptedException e) { logger.error("Simulation interrupted", e); Thread.currentThread().interrupt(); break; }
   }
   System.out.println("Cloning temperature sensor (clone starts with no observers)...");
   Sensor clone = temp.clone();
   clone.setReading(99); // no dashboard/logger notifications from clone
   clone.register(dashboard);
   clone.setReading(25); // dashboard notified only
   temp.unregister(dashboard);
   System.out.println("Dashboard unregistered from original temperature sensor.");
   temp.setReading(26); // logger notified only
  } catch (RuntimeException e) { logger.error("Application failed", e); throw e; }
  finally { logger.info("Application stopping"); }
 }
}
