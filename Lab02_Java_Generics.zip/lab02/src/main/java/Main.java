import java.util.Arrays;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        System.out.println("=== Exercise 1: PrintableList ===");
        PrintableList<String> names = new PrintableList<>(new String[]{"Ali", "Sara", "Omar"});
        names.printItems();

        System.out.println("\n=== Exercise 2: NumberBox ===");
        NumberBox<Integer> integerBox = new NumberBox<>(10);
        System.out.println("Integer item: " + integerBox.getItem());
        integerBox.setItem(20);
        System.out.println("Updated integer: " + integerBox.getItem());
        System.out.println("20 + 5 = " + integerBox.add(5));

        NumberBox<Double> doubleBox = new NumberBox<>(12.5);
        System.out.println("Double item: " + doubleBox.getItem());
        System.out.println("12.5 + 2.5 = " + doubleBox.add(2.5));
        System.out.println("Integer list sum: " + NumberBox.sumNumbers(Arrays.asList(1, 2, 3, 4)));
        System.out.println("Double list sum: " + NumberBox.sumNumbers(Arrays.asList(1.5, 2.5, 3.0)));

        System.out.println("\n=== Exercise 3: Pipeline ===");
        PipeLine<String, String> original = PipeLine.start();
        PipeLine<String, Integer> lengthPipeline = original
                .add(String::trim)
                .add(String::toUpperCase)
                .add(String::length);
        System.out.println("Length after trim and uppercase: " + lengthPipeline.execute("  hello  "));
        System.out.println("Original pipeline still returns input: " + original.execute("  hello  "));

        PipeLine<Integer, String> numberPipeline = PipeLine.<Integer>start()
                .add(number -> number * 2)
                .add(number -> "Result: " + number);
        System.out.println(numberPipeline.execute(7));

        System.out.println("\n=== Exercise 4: Wildcards ===");
        printList(Arrays.asList("Java", "Generics", "Wildcards"));
        printList(Arrays.asList(10, 20, 30));
        System.out.println("Integer wildcard sum: " + sumNumbers(Arrays.asList(10, 20, 30)));
        System.out.println("Double wildcard sum: " + sumNumbers(Arrays.asList(1.5, 2.5, 3.5)));
    }

    public static void printList(List<?> items) {
        for (Object item : items) {
            System.out.println(item);
        }
    }

    public static double sumNumbers(List<? extends Number> numbers) {
        double sum = 0;
        for (Number number : numbers) {
            sum += number.doubleValue();
        }
        return sum;
    }
}
