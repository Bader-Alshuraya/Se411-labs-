import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class PrintableList<T> {
    private final List<T> items;

    public PrintableList(T[] values) {
        this.items = new ArrayList<>(Arrays.asList(values));
    }

    public void printItems() {
        for (T item : items) {
            System.out.println(item);
        }
    }
}
