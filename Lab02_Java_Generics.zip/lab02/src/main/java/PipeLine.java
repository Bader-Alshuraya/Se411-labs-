import java.util.ArrayList;
import java.util.List;

/**
 * Immutable, type-safe pipeline. Each step is stored in execution order.
 * The unchecked implementation detail is isolated to Object-based internal
 * dispatch; the public add() signature guarantees compatible step types.
 */
public class PipeLine<T, R> {
    private final List<Transformer<Object, Object>> steps;

    private PipeLine(List<Transformer<Object, Object>> steps) {
        this.steps = steps;
    }

    public static <T> PipeLine<T, T> start() {
        return new PipeLine<>(new ArrayList<>());
    }

    @SuppressWarnings("unchecked")
    public <Next> PipeLine<T, Next> add(Transformer<? super R, ? extends Next> transformer) {
        List<Transformer<Object, Object>> nextSteps = new ArrayList<>(steps);
        nextSteps.add(value -> transformer.transform((R) value));
        return new PipeLine<>(nextSteps);
    }

    public R execute(T input) {
        Object result = input;
        for (Transformer<Object, Object> step : steps) {
            result = step.transform(result);
        }
        @SuppressWarnings("unchecked")
        R output = (R) result;
        return output;
    }
}
