# SE411 – Lab 02: Introduction to Java Generics

Complete solutions to the four exercises in the Fall 2026–2027 lab handout.

## Exercises

1. `PrintableList<T>`: stores an array in a `List<T>` and prints each item.
2. `NumberBox<T extends Number>`: wraps a number, exposes setters/getters, adds numbers, and sums lists of numbers.
3. `Transformer<T,R>` and `PipeLine<T,R>`: a typed pipeline supporting both same-type and type-changing transformations. Each `add` returns a new pipeline; `execute` runs the transformations in order.
4. `Main.printList(List<?>)` and `Main.sumNumbers(List<? extends Number>)`: wildcard practice.

## Run (Java 8 or newer)

From the `lab02` folder:

```bash
mkdir -p out
javac -d out src/main/java/*.java
java -cp out Main
```

Alternatively, open this folder in a Java IDE and run `Main.java`. No external dependencies are required.

## GitHub submission

Commit the `lab02` folder inside your `se411_labs` repository. Do not commit the generated `out` directory.
