package edu.psu.se411.lab09_inventory;

import java.util.List;
import edu.psu.se411.lab09_inventory.model.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class App {
 private static final Logger logger=LoggerFactory.getLogger(App.class);
 public static void displayInventory(Inventory<?> inventory){for(Object item:inventory.getAllItems())System.out.println(item);}
 public static void main(String[] args){
  logger.info("Application is starting...");
  try {
   Inventory<Item> inventory=new Inventory<>();
   Book book=new Book("B01","Concurrency in Java","Salah Ahmed");
   inventory.addItem(book);
   inventory.addItem(new Book("B02","Design Patterns","Erich Gamma"));
   inventory.addItem(new ElectronicDevice("E01","Laptop","Computers"));
   inventory.addItem(new ElectronicDevice("E02","Smartphone","Phones"));
   System.out.println("=== All inventory items ===");displayInventory(inventory);
   System.out.println("=== Search by name ===");System.out.println(inventory.findItems(new SearchByName("Concurrency in Java")));
   System.out.println("=== Device by name ===");System.out.println(inventory.findItems(new SearchByName("Laptop")));
   System.out.println("=== Search by ID ===");System.out.println(inventory.findItems(new SearchById("E01")));
   System.out.println("=== Search by author ===");System.out.println(inventory.findItems(new SearchByAuthor("Erich Gamma")));
   System.out.println("=== Search by category ===");System.out.println(inventory.findItems(new SearchByCategory("Computers")));
   SearchStrategy<Item> lambda=item->item.getName().startsWith("S");
   System.out.println("=== Lambda search ===");System.out.println(inventory.findItems(lambda));
   inventory.removeItem(book);System.out.println("=== After removing B01 ===");displayInventory(inventory);
  } catch(Exception e){logger.error("Inventory operation failed",e);throw e;}
  finally {logger.info("Application is closing...");}
 }
}