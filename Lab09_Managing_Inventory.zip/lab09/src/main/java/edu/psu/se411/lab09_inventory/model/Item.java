package edu.psu.se411.lab09_inventory.model;

public abstract class Item {
 private final String id, name;
 protected Item(String id, String name) { if(id==null||id.isBlank()||name==null||name.isBlank()) throw new IllegalArgumentException("ID and name required"); this.id=id;this.name=name; }
 public String getId(){return id;} public String getName(){return name;}
 @Override public String toString(){return "id="+id+", name="+name;}
}