package edu.psu.se411.lab09_inventory.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
public class Inventory<T> {
 private final List<T> items = new ArrayList<>();
 public void addItem(T item){items.add(Objects.requireNonNull(item));}
 public boolean removeItem(T item){return items.remove(item);}
 public List<T> getAllItems(){return Collections.unmodifiableList(new ArrayList<>(items));}
 public List<T> findItems(SearchStrategy<? super T> strategy){Objects.requireNonNull(strategy);List<T> results=new ArrayList<>();for(T item:items)if(strategy.matches(item))results.add(item);return results;}
 public List<T> findItem(SearchStrategy<? super T> strategy){return findItems(strategy);}
}