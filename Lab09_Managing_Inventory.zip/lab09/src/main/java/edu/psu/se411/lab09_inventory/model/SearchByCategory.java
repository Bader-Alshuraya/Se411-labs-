package edu.psu.se411.lab09_inventory.model;

public class SearchByCategory implements SearchStrategy<Item> {
 private final String category;public SearchByCategory(String category){this.category=category;}
 public boolean matches(Item item){return item instanceof ElectronicDevice && ((ElectronicDevice)item).getCategory().equalsIgnoreCase(category);}
}