package edu.psu.se411.lab09_inventory.model;

public class SearchByAuthor implements SearchStrategy<Item> {
 private final String author;public SearchByAuthor(String author){this.author=author;}
 public boolean matches(Item item){return item instanceof Book && ((Book)item).getAuthor().equalsIgnoreCase(author);}
}