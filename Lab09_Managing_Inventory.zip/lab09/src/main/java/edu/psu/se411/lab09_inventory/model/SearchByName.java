package edu.psu.se411.lab09_inventory.model;

public class SearchByName implements SearchStrategy<Item> {
 private final String name;public SearchByName(String name){this.name=name;}
 public boolean matches(Item item){return item.getName().equalsIgnoreCase(name);}
}