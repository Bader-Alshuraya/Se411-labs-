# Lab 09 – Managing Inventory with the Strategy Pattern

SE411 Java Maven lab. Uses the original starter project's package name and SLF4J file logging.

## Exercises
- Part 1: Generic `Inventory<T>` with add, remove and list methods; `Item`, `Book`, `ElectronicDevice`.
- Part 2: `SearchStrategy<T>` with ID, name, author and category strategies plus a lambda expression. `findItems` returns all matches; `findItem` is an alias for the assignment's inconsistent singular wording.
- Part 3: `displayInventory(Inventory<?>)` prints any inventory's contents.

## Run
Requires Java 17+ and Maven:

```bash
mvn clean package exec:java
```

Logs are written to `logs/log.out`. Search strategies for author and category accept `Item` so they can operate on a mixed `Inventory<Item>` and ignore nonmatching item subclasses.
