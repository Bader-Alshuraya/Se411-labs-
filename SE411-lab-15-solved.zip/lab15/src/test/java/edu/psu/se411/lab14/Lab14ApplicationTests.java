package edu.psu.se411.lab14;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@org.springframework.test.context.ActiveProfiles("test")
@SpringBootTest
class Lab14ApplicationTests {

	@Test
	void contextLoads() {
	}

}
