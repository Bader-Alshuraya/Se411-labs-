package edu.psu.se411.lab14.repository;
import org.springframework.data.repository.CrudRepository;
import edu.psu.se411.lab14.model.Product;
public interface ProductRepository extends CrudRepository<Product,Long> {}
