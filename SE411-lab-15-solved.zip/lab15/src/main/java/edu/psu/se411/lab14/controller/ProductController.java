package edu.psu.se411.lab14.controller;
import java.net.URI;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
import edu.psu.se411.lab14.model.Product;
import edu.psu.se411.lab14.repository.ProductRepository;
@RestController @RequestMapping("/api/v1/products")
public class ProductController {
 private final ProductRepository repository;
 public ProductController(ProductRepository repository) { this.repository=repository; }
 @GetMapping public Iterable<Product> all() { return repository.findAll(); }
 @GetMapping("/{id}") public ResponseEntity<Product> one(@PathVariable Long id) {
  return repository.findById(id).map(ResponseEntity::ok).orElseGet(()->ResponseEntity.notFound().build());
 }
 @PostMapping public ResponseEntity<Void> create(@Valid @RequestBody Product product) {
  if(product.id()!=null) return ResponseEntity.badRequest().build();
  Product saved=repository.save(product);
  return ResponseEntity.created(URI.create("/api/v1/products/"+saved.id())).build();
 }
 @PutMapping("/{id}") public ResponseEntity<Void> update(@PathVariable Long id, @Valid @RequestBody Product p) {
  if(p.id()!=null) return ResponseEntity.badRequest().build();
  if(!repository.existsById(id)) return ResponseEntity.notFound().build();
  repository.save(new Product(id,p.name(),p.description(),p.price()));
  return ResponseEntity.noContent().build();
 }
 @DeleteMapping("/{id}") public ResponseEntity<Void> delete(@PathVariable Long id) {
  if(!repository.existsById(id)) return ResponseEntity.notFound().build();
  repository.deleteById(id); return ResponseEntity.noContent().build();
 }
}
