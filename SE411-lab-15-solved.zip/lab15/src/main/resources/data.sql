INSERT INTO course(code,name,description,credits)
 SELECT 'SE201','Introduction to software engineering','This course is an intro to SE',3
 WHERE NOT EXISTS (SELECT 1 FROM course WHERE code='SE201');
INSERT INTO product(name,description,price)
 SELECT '3d printer','A beginner friendly 3d printer',1840.25
 WHERE NOT EXISTS (SELECT 1 FROM product WHERE name='3d printer');
