# Lab 15 solution

See the parent README for JDK, MySQL configuration and test commands. Use your own MySQL connection and an empty database named `se411_lab15`. The default port is 3000.

No authentication in this lab.

The demo credentials are for this exercise. Seeded database passwords are BCrypt hashes. 

API collection: `requests.postman_collection.json`.
Course endpoints are `/api/v1/courses` and `/api/v1/courses/{id}`. The supplied starter uses courses, so these are retained. The product endpoints from the handout are implemented too.

CRUD responses: list/get = 200; create = 201 with the saved resource ID in Location; update/delete = 204; missing IDs = 404. 

Run `.\mvnw.cmd test` to execute the isolated H2 tests. These exercise application behavior without needing Aiven. A live MySQL/Aiven check still requires your actual database connection.
