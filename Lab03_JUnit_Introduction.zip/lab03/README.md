# SE411 — Lab 03: JUnit Introduction

This is the completed Maven starter project for Lab 03. The original `Stack<E>` implementation is preserved, and JUnit 5 tests are added in the matching package.

## Exercises

- `push_push_pop_returnsLatestPushedElement`: push Z, push A, then verify pop returns A.
- `pop_empty_stack_throwsException`: verify `NoSuchElementException` and the original implementation's exception message.
- `pushedElements_arePoppedInReverseOrder`: verify LIFO order for three elements.
- `pop_afterRemovingAllElements_throwsException`: additional edge-case test.

## Run tests

From this directory, with Java 11+ and Maven installed:

```bash
mvn test
```

The `pom.xml` includes JUnit Jupiter 5.11.0 and Maven Surefire for test discovery.

## Intentionally failing assertion (exercise demonstration)

For the lab's temporary failure demonstration, change `assertEquals("A", stringStack.pop())` to `assertEquals("Z", stringStack.pop())` in the first test and run `mvn test`. Restore `"A"` before submission so the final suite passes.

**Note:** The handout's example error text is `Stack is empty,can’t pop`, but the provided `Stack.java` actually throws `Stack is empty, cannot pop`. The test matches the provided source code, without modifying the stack implementation.

The original RAR included Eclipse metadata and compiled `target/` artifacts; those are unnecessary for a portable Maven project and have been omitted.
