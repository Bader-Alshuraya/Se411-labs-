package edu.psu.se411.model;

import static org.junit.jupiter.api.Assertions.*;

import java.util.NoSuchElementException;
import org.junit.jupiter.api.Test;

public class StackTest {

    @Test
    public void push_push_pop_returnsLatestPushedElement() {
        Stack<String> stringStack = new Stack<>();
        stringStack.push("Z");
        stringStack.push("A");
        assertEquals("A", stringStack.pop());
    }

    @Test
    public void pop_empty_stack_throwsException() {
        Stack<String> stringStack = new Stack<>();
        NoSuchElementException thrown = assertThrows(
            NoSuchElementException.class,
            () -> stringStack.pop(),
            "Expected pop from empty Stack to throw, but it didn't"
        );
        assertEquals("Stack is empty, cannot pop", thrown.getMessage());
    }

    @Test
    public void pushedElements_arePoppedInReverseOrder() {
        Stack<String> stringStack = new Stack<>();
        stringStack.push("First");
        stringStack.push("Second");
        stringStack.push("Third");
        assertEquals("Third", stringStack.pop());
        assertEquals("Second", stringStack.pop());
        assertEquals("First", stringStack.pop());
    }

    @Test
    public void pop_afterRemovingAllElements_throwsException() {
        Stack<Integer> stack = new Stack<>();
        stack.push(10);
        assertEquals(10, stack.pop());
        assertThrows(NoSuchElementException.class, stack::pop);
    }
}
