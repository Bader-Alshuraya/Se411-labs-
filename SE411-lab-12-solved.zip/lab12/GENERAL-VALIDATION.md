# Verification results

Verified using Microsoft OpenJDK 21.0.13 and Maven 3.9.9. All 19 executed tests passed.

| Lab | Tests | Failures | Errors |
| --- | --- | --- | --- |
| 12 | 3 | 0 | 0 |
| 15 | 2 | 0 | 0 |
| 16 | 5 | 0 | 0 |
| 17 | 5 | 0 | 0 |
| 19 | 4 | 0 | 0 |

Spring checks cover all five product CRUD operations and missing records; form login, password rejection, missing-CSRF rejection, USER/ADMIN access, course CRUD and logout; Basic authentication success and rejection; database password changes; and stateless requests. Lab 12 tests cover rejected transfers, invalid amounts and concurrent opposing transfers with duplicate IDs.

Lab 12 also completed 12 million-transaction benchmark runs: fixed/cached pools × 1,000/10 accounts × three repetitions. Every run preserved exact total cents and nonnegative balances. Raw results and written answers are in lab12.

Spring integration tests use real Spring Data repositories and real security filters with an isolated H2 database in MySQL compatibility mode. A live MySQL/Aiven server was not configured, and no cloud setup or Postman UI execution is claimed. MySQL scripts, connection configuration, and Postman collections are included for that final environment check.

All four Spring projects completed Maven package successfully. Windows sandbox restrictions caused Java to report AccessDeniedException during canonical-path resolution and compiler resource cleanup. For Lab 12, compiled main classes were exercised by the benchmarks; its test source was compiled using a merged temporary classpath JAR, then Maven Surefire executed all three tests successfully. The temporary compiler setup is excluded from the deliverable. Normal Maven commands are documented for use outside this sandbox.

Source archives exclude build outputs, IDE metadata, original handouts and private database credentials. Human-readable Surefire results are included in each lab's verification folder.
