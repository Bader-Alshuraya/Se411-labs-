package edu.psu.se411.lab12_threads;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.time.Duration;
import java.util.concurrent.*;
import edu.psu.se411.lab12_threads.model.*;
import edu.psu.se411.lab12_threads.exceptions.InsufficientBalanceException;
class TransferTest {
 @Test void overdraftIsAtomicAndLocksAreReleased() throws Exception {
  CryptoAccount a=new CryptoAccount("a",10.0),b=new CryptoAccount("b",20.0);
  assertThrows(InsufficientBalanceException.class,()->a.transferTo(b,11.0));
  assertEquals(1000L,a.getBalanceInCents()); assertEquals(2000L,b.getBalanceInCents());
  a.transferTo(b,5.0); assertEquals(500L,a.getBalanceInCents()); assertEquals(2500L,b.getBalanceInCents());
 }
 @Test void oppositeTransfersAndDuplicateIdsDoNotDeadlock() {
  assertTimeoutPreemptively(Duration.ofSeconds(15),()->{
   CryptoAccount a=new CryptoAccount("same",10000.0),b=new CryptoAccount("same",10000.0);
   ExecutorService pool=Executors.newFixedThreadPool(8,r->{Thread t=new Thread(r); t.setDaemon(true); return t;});
   try {
    java.util.List<Future<?>> futures=new java.util.ArrayList<>();
    for(int i=0;i<20000;i++) { final boolean even=i%2==0;
     futures.add(pool.submit(()->new Transaction("t",even?a:b,even?b:a,1.0).run())); }
    for(Future<?> f:futures) f.get();
   } finally { pool.shutdownNow(); }
   assertEquals(2_000_000L,a.getBalanceInCents()+b.getBalanceInCents());
   assertTrue(a.getBalanceInCents()>=0); assertTrue(b.getBalanceInCents()>=0);
  });
 }
 @Test void invalidAmountsAreRejected() {
  CryptoAccount a=new CryptoAccount("a",1.0);
  assertThrows(IllegalArgumentException.class,()->a.retrieveFromBalance(-1.0));
  assertThrows(IllegalArgumentException.class,()->a.addToBalance(Double.NaN));
 }
}
