package edu.psu.se411.lab12_threads.model;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.ReentrantLock;
import edu.psu.se411.lab12_threads.exceptions.InsufficientBalanceException;
public class CryptoAccount {
 private static final AtomicLong NEXT_ORDER=new AtomicLong();
 private final long tieBreaker=NEXT_ORDER.getAndIncrement();
 private final String id;
 private long cents;
 private final ReentrantLock lock=new ReentrantLock();
 public CryptoAccount(String id, Double balance) {
  if(id==null || id.isBlank()) throw new IllegalArgumentException("Account ID required");
  this.id=id; cents=toCents(balance);
 }
 private static long toCents(Double amount) {
  if(amount==null || !Double.isFinite(amount) || amount<0) throw new IllegalArgumentException("Finite nonnegative amount required");
  return BigDecimal.valueOf(amount).setScale(2,RoundingMode.HALF_UP).movePointRight(2).longValueExact();
 }
 public void addToBalance(Double amount) {
  long value=toCents(amount); lock.lock();
  try { cents=Math.addExact(cents,value); } finally { lock.unlock(); }
 }
 public void retrieveFromBalance(Double amount) throws InsufficientBalanceException {
  long value=toCents(amount); lock.lock();
  try { if(value>cents) throw new InsufficientBalanceException(id); cents-=value; }
  finally { lock.unlock(); }
 }
 private int compareOrder(CryptoAccount other) {
  int c=id.compareTo(other.id);
  return c!=0 ? c : Long.compare(tieBreaker,other.tieBreaker);
 }
 public void transferTo(CryptoAccount receiver, Double amount) throws InsufficientBalanceException {
  if(receiver==null || receiver==this) throw new IllegalArgumentException("Distinct receiver required");
  long value=toCents(amount);
  CryptoAccount first=compareOrder(receiver)<0 ? this : receiver;
  CryptoAccount second=first==this ? receiver : this;
  // Every transfer acquires the same total order, including opposite transfers.
  first.lock.lock();
  try {
   second.lock.lock();
   try {
    if(cents<value) throw new InsufficientBalanceException(id);
    long newReceiverBalance=Math.addExact(receiver.cents,value);
    cents-=value; receiver.cents=newReceiverBalance;
   } finally { second.lock.unlock(); }
  } finally { first.lock.unlock(); }
 }
 public String getId() { return id; }
 public long getBalanceInCents() { lock.lock(); try { return cents; } finally { lock.unlock(); } }
 public Double getBalance() { return getBalanceInCents()/100.0; }
}
