package edu.psu.se411.lab12_threads;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import edu.psu.se411.lab12_threads.model.*;
public final class Benchmark {
 private Benchmark() {}
 public static void run(boolean cached,String[] args) throws InterruptedException {
  int count=args.length>0 ? Integer.parseInt(args[0]) : 1000;
  int transactions=args.length>1 ? Integer.parseInt(args[1]) : 1_000_000;
  int workers=args.length>2 ? Integer.parseInt(args[2]) : 8;
  if(count<2 || transactions<1 || workers<1) throw new IllegalArgumentException();
  CryptoAccount[] accounts=new CryptoAccount[count];
  for(int i=0;i<count;i++) accounts[i]=new CryptoAccount("acc_"+i,10_000.0);
  long before=total(accounts);
  // Identical workload for both programs; generation is outside the timed interval.
  Random random=new Random(411);
  Transaction[] tasks=new Transaction[transactions];
  for(int i=0;i<transactions;i++) {
   int from=random.nextInt(count),to=random.nextInt(count-1); if(to>=from) to++;
   tasks[i]=new Transaction("tx_"+i,accounts[from],accounts[to],random.nextInt(10001)/100.0);
  }
  AtomicInteger created=new AtomicInteger();
  ThreadFactory factory=task->{Thread t=new Thread(task,"transfer-"+created.incrementAndGet()); t.setDaemon(true); return t;};
  ExecutorService pool=cached ? Executors.newCachedThreadPool(factory) : Executors.newFixedThreadPool(workers,factory);
  java.util.concurrent.atomic.AtomicReference<Throwable> failure=new java.util.concurrent.atomic.AtomicReference<>();
  long start=System.nanoTime();
  try {
   for(Transaction task:tasks) pool.execute(()->{ try { task.run(); } catch(Throwable ex) { failure.compareAndSet(null,ex); } });
  } finally { pool.shutdown(); }
  if(!pool.awaitTermination(120,TimeUnit.SECONDS)) { pool.shutdownNow(); throw new IllegalStateException("Benchmark timed out"); }
  double ms=(System.nanoTime()-start)/1_000_000.0;
  if(failure.get()!=null) throw new IllegalStateException("Worker failed",failure.get());
  long after=total(accounts);
  if(before!=after) throw new AssertionError("Money was not conserved");
  for(CryptoAccount a:accounts) if(a.getBalanceInCents()<0) throw new AssertionError("Negative balance");
  System.out.printf(Locale.ROOT,"%s,%d,%d,%d,%.3f,%d,%d%n",cached?"cached":"fixed",count,transactions,created.get(),ms,before,after);
 }
 private static long total(CryptoAccount[] accounts) { long total=0; for(CryptoAccount a:accounts) total+=a.getBalanceInCents(); return total; }
}
