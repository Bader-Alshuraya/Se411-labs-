package edu.psu.se411.lab12_threads.model;
import edu.psu.se411.lab12_threads.exceptions.InsufficientBalanceException;
public final class Transaction implements Runnable {
 private final String id;
 private final CryptoAccount sender,receiver;
 private final Double amount;
 public Transaction(String id,CryptoAccount sender,CryptoAccount receiver,Double amount) {
  if(id==null || sender==null || receiver==null || sender==receiver || amount==null || !Double.isFinite(amount) || amount<0)
   throw new IllegalArgumentException("Invalid transaction");
  this.id=id; this.sender=sender; this.receiver=receiver; this.amount=amount;
 }
 @Override public void run() {
  try { execute(); } catch(InsufficientBalanceException expected) { /* Rejected; neither account changes. */ }
 }
 public void execute() throws InsufficientBalanceException { sender.transferTo(receiver,amount); }
 public String getId() { return id; }
 public CryptoAccount getSender() { return sender; }
 public CryptoAccount getReceiver() { return receiver; }
 public Double getAmount() { return amount; }
}
