# SE411 solved labs 12, 15, 16, 17 and 19

Each lab is an independent Maven project based on its supplied starter. Open/import the folder containing its pom.xml in your IDE. Use JDK 21 (not Java 8). Maven wrappers download Maven 3.9.9 on first use.

## Run tests
In each lab folder, run `.\mvnw.cmd test` in PowerShell, or `./mvnw test` on Linux/macOS (run `chmod +x mvnw` first if necessary).
Spring tests use H2 in MySQL compatibility mode via the test profile, so no cloud account is needed to run the automated tests. The normal applications use MySQL. See VALIDATION.md for the actual test results and limits.

## Run Spring labs with your MySQL database
1. Create a separate empty database for each lab, using MySQL Workbench, Aiven, or another MySQL client. For example: `CREATE DATABASE se411_lab15;` (repeat for 16, 17, 19). For Aiven use the host and port displayed in your own service and create the database there.
2. In that lab's PowerShell terminal, set your own connection details:
   ```powershell
   $env:JAVA_HOME = 'C:\path\to\jdk-21'
   $env:DB_URL = 'jdbc:mysql://YOUR_HOST:YOUR_PORT/se411_lab15?sslMode=REQUIRED'
   $env:DB_USER = 'YOUR_USERNAME'
   $env:DB_PASSWORD = 'YOUR_PASSWORD'
   $env:DB_INIT = 'always'
   .\mvnw.cmd spring-boot:run
   ```
   Change the database name for each lab. `sslMode=REQUIRED` matches the cloud lab setup; a local MySQL instance without TLS needs its own local-only connection settings.
3. SQL initialization is opt-in. On the first start, `DB_INIT=always` creates and seeds the tables. Scripts use `IF NOT EXISTS` and insert-if-missing statements rather than dropping your data. After initialization, use `$env:DB_INIT='never'` for subsequent starts. Sample users/products are not recreated or reset if already present.
4. Lab 15 runs on port 3000; other Spring labs use 8080. Run one at a time or set `$env:PORT='8081'` for another port.

No cloud account has been created or database credentials inferred from the handouts. Use your own credentials; example connection strings in handouts are not used.

## What is included
| Lab | Solution |
| --- | --- |
| 12 | Fixed and cached pool main programs; explicit locks; deadlock-free total resource ordering; million-transaction measurements and written answers |
| 15 | MySQL course API from the starter plus the product API used by the handout; all five CRUD operations |
| 16 | Form login, BCrypt users, public home, USER dashboard, ADMIN dashboard, CSRF protection and session logout |
| 17 | Stateless Basic authentication with two BCrypt users in MySQL and a UserDetails adapter/repository/service |
| 19 | Replaces the starter's in-memory users with MySQL repository-backed authentication; one seeded user |

For Spring labs, import `requests.postman_collection.json` into Postman. Collections include sample CRUD requests and response assertions. Lab 16 also captures CSRF tokens and uses the Postman cookie jar. Run collections in order against a freshly seeded lab database.

## Compatibility choices
The archives mixed Spring Boot 3 and 4, Java 21/23/24, and Maven wrapper versions. All Spring solutions use the supplied Lab 16/19 baseline, Spring Boot 3.5.7, and all projects target Java 21 for one consistent toolchain. Modern `com.mysql:mysql-connector-j` is managed by Spring Boot. Lab 16 adds the missing Thymeleaf starter so the supplied templates render.

Reference: [Spring Security Basic authentication](https://docs.spring.io/spring-security/reference/servlet/authentication/passwords/basic.html), [repository-backed UserDetailsService](https://docs.spring.io/spring-security/reference/servlet/authentication/passwords/user-details-service.html).
