package edu.psu.se411.lab11_threads.model;

public class CryptoAccount {
    private final int id;
    private int balance;
    public CryptoAccount(int id, int balance) { this.id=id; this.balance=balance; }
    public int getId() { return id; }
    public int getBalance() { return balance; }
    // Deliberately unsafe operations, for part one of the lab.
    public void withdraw(int amount) { int updated=balance-amount; Thread.yield(); balance=updated; }
    public void deposit(int amount) { int updated=balance+amount; Thread.yield(); balance=updated; }
}
