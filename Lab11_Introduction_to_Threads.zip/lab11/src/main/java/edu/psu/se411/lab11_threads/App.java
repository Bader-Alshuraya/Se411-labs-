package edu.psu.se411.lab11_threads;

import edu.psu.se411.lab11_threads.model.CryptoAccount;
import edu.psu.se411.lab11_threads.model.Transaction;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import java.util.logging.*;

public class App {
    private static final Logger LOG=Logger.getLogger(App.class.getName());
    private static final int ACCOUNTS=10, STARTING_BALANCE=1000, TRANSACTIONS=10000;
    public static void main(String[] args) throws Exception {
        configureLogger();
        LOG.info("Lab 11 started");
        try {
            runScenario(false);
            runScenario(true);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt(); LOG.log(Level.SEVERE,"Interrupted",e); throw e;
        } catch (RuntimeException e) {
            LOG.log(Level.SEVERE,"Application failed",e); throw e;
        } finally { LOG.info("Lab 11 stopped"); }
    }
    private static void runScenario(boolean safe) throws InterruptedException {
        List<CryptoAccount> accounts=new ArrayList<>();
        for(int i=0;i<ACCOUNTS;i++) accounts.add(new CryptoAccount(i+1,STARTING_BALANCE));
        int initial=total(accounts);
        List<Thread> threads=new ArrayList<>(TRANSACTIONS);
        for(int i=0;i<TRANSACTIONS;i++) {
            int a=ThreadLocalRandom.current().nextInt(ACCOUNTS);
            int b=ThreadLocalRandom.current().nextInt(ACCOUNTS-1);
            if(b>=a) b++;
            int amount=ThreadLocalRandom.current().nextInt(1,101);
            Thread t=new Thread(new Transaction(accounts.get(a),accounts.get(b),amount,safe));
            threads.add(t);
            t.start();
        }
        for(Thread t:threads) t.join();
        int ending=total(accounts);
        String label=safe?"SYNCHRONIZED":"UNSYNCHRONIZED";
        System.out.printf("%s | Initial: %d SAR | Final: %d SAR | Difference: %+d SAR%n",label,initial,ending,ending-initial);
        LOG.info(label+" completed: initial="+initial+", final="+ending);
        if(safe && ending!=initial) throw new AssertionError("Synchronized transactions changed total balance");
    }
    public static int total(List<CryptoAccount> accounts) {
        int sum=0; for(CryptoAccount account:accounts) sum+=account.getBalance(); return sum;
    }
    private static void configureLogger() throws Exception {
        java.nio.file.Files.createDirectories(java.nio.file.Paths.get("logs"));
        LOG.setUseParentHandlers(false);
        FileHandler file=new FileHandler("logs/lab11.log",true);
        file.setFormatter(new SimpleFormatter()); LOG.addHandler(file);
    }
}
