package edu.psu.se411.lab11_threads.model;

public class Transaction implements Runnable {
    private final CryptoAccount sender, receiver;
    private final int amount;
    private final boolean synchronizedMode;
    public Transaction(CryptoAccount sender, CryptoAccount receiver, int amount, boolean synchronizedMode) {
        this.sender=sender; this.receiver=receiver; this.amount=amount; this.synchronizedMode=synchronizedMode;
    }
    @Override public void run() {
        if (synchronizedMode) transferSafely(sender,receiver,amount);
        else transferUnsafely(sender,receiver,amount);
    }
    private static void transferUnsafely(CryptoAccount from, CryptoAccount to, int amount) {
        if (from.getBalance()>=amount) { from.withdraw(amount); to.deposit(amount); }
    }
    // One class-level lock protects the entire debit/credit transaction.
    public static synchronized void transferSafely(CryptoAccount from, CryptoAccount to, int amount) {
        if (from.getBalance()>=amount) { from.withdraw(amount); to.deposit(amount); }
    }
}
