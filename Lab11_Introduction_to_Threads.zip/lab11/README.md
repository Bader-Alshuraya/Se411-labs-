# Lab 11 — Introduction to Threads

SE411: Double Spending Problem. This project runs two experiments, each starting with ten crypto accounts containing 1,000 SAR and executing 10,000 random transactions using 10,000 Java threads.

- **Unsynchronized:** deliberately uses unsafe read/modify/write balance updates. Its final total can be wrong due to race conditions; the amount varies per run, and an occasional run can still total 10,000.
- **Synchronized:** `Transaction.transferSafely` uses a single `static synchronized` method so a withdrawal and deposit form one atomic transfer. The total remains 10,000 SAR.

## Run

Requires JDK 17+ and Maven:

```sh
mvn clean package exec:java
```

Or compile and run directly from the `lab11` directory:

```sh
javac -d out src/main/java/edu/psu/se411/lab11_threads/model/*.java src/main/java/edu/psu/se411/lab11_threads/App.java
java -cp out edu.psu.se411.lab11_threads.App
```

Logs are written to `logs/lab11.log` and are excluded from Git. Integer riyal transfers are used to avoid floating-point rounding errors.

**Note:** The provided RAR archive was inspected for its file listing, but its contents could not be extracted in this environment. This is a standalone reconstruction matching the assignment, not a byte-for-byte modification of the starter project.
