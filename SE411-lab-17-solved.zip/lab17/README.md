# Lab 17 solution

See the parent README for JDK, MySQL configuration and test commands. Use your own MySQL connection and an empty database named `se411_lab17`. The default port is 8080.

Basic credentials: `usera / pwd123` and `userb / pwd456`.

The demo credentials are for this exercise. Seeded database passwords are BCrypt hashes. Authentication is implemented by UserRepository → MyUserDetailsService → UserPrincipal, with stateless sessions and explicit httpBasic. There is no InMemoryUserDetailsManager in this project. CSRF is disabled for the stateless API as required by the lab.

API collection: `requests.postman_collection.json`.
Product endpoints: `/api/v1/products` and `/api/v1/products/{id}`.

CRUD responses: list/get = 200; create = 201 with the saved resource ID in Location; update/delete = 204; missing IDs = 404. Missing/incorrect Basic credentials = 401. Each request must include credentials; a previous login does not create an authenticated session.

Run `.\mvnw.cmd test` to execute the isolated H2 tests. These exercise application behavior without needing Aiven. A live MySQL/Aiven check still requires your actual database connection.
