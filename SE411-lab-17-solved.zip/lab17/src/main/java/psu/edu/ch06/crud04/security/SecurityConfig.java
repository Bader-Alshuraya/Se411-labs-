package psu.edu.ch06.crud04.security;
import org.springframework.context.annotation.*;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
@Configuration @EnableWebSecurity
public class SecurityConfig {
 @Bean public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
  return http.csrf(csrf -> csrf.disable())
   .authorizeHttpRequests(r -> r.anyRequest().authenticated())
   .httpBasic(Customizer.withDefaults())
   .sessionManagement(s -> s.sessionCreationPolicy(SessionCreationPolicy.STATELESS)).build();
 }
 @Bean public PasswordEncoder passwordEncoder() { return new BCryptPasswordEncoder(12); }
}
