INSERT INTO product(name,description,price)
 SELECT '3d printer','A beginner friendly 3d printer',1840.25
 WHERE NOT EXISTS (SELECT 1 FROM product WHERE name='3d printer');
INSERT INTO app_user(username,password)
 SELECT 'usera','$2a$12$LBRUgRp44wAQ2mPobEXZme8zHazvPa/jOgEIqjR2oDWpe5qHGq.5a' WHERE NOT EXISTS (SELECT 1 FROM app_user WHERE username='usera');
INSERT INTO app_user(username,password) SELECT 'userb','$2a$12$cgSeKnHsGIjQULLfl9xbb.ROjmSluZ4FU9JgPy9xIobbhUxngR6pK' WHERE NOT EXISTS (SELECT 1 FROM app_user WHERE username='userb');
