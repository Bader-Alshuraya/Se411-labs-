package psu.edu.ch06.crud04;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@org.springframework.test.context.ActiveProfiles("test")
@SpringBootTest
class Crud04ApplicationTests {

	@Test
	void contextLoads() {
	}

}
