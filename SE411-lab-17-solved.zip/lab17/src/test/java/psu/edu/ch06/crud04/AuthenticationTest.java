package psu.edu.ch06.crud04;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.crypto.password.PasswordEncoder;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.httpBasic;
import static org.junit.jupiter.api.Assertions.*;
@SpringBootTest @AutoConfigureMockMvc @ActiveProfiles("test")
class AuthenticationTest {
 @Autowired MockMvc mvc;
 @Autowired JdbcTemplate jdbc;
 @Autowired PasswordEncoder encoder;
 @Test void missingWrongAndUnknownCredentialsAreRejected() throws Exception {
  mvc.perform(get("/api/v1/products")).andExpect(status().isUnauthorized());
  mvc.perform(get("/api/v1/products").with(httpBasic("usera","wrong"))).andExpect(status().isUnauthorized());
  mvc.perform(get("/api/v1/products").with(httpBasic("unknown","pwd123"))).andExpect(status().isUnauthorized());
 }
 @Test void credentialsAreLoadedFromDatabaseAndRequestsAreStateless() throws Exception {
  String original=jdbc.queryForObject("SELECT password FROM app_user WHERE username='usera'",String.class);
  assertTrue(encoder.matches("pwd123",original));
  try {
   jdbc.update("UPDATE app_user SET password=? WHERE username='usera'",encoder.encode("changed123"));
   mvc.perform(get("/api/v1/products").with(httpBasic("usera","pwd123"))).andExpect(status().isUnauthorized());
   var response=mvc.perform(get("/api/v1/products").with(httpBasic("usera","changed123")))
    .andExpect(status().isOk()).andReturn();
   assertNull(response.getRequest().getSession(false));
   mvc.perform(get("/api/v1/products")).andExpect(status().isUnauthorized());
  } finally { jdbc.update("UPDATE app_user SET password=? WHERE username='usera'",original); }
 }
 @Test void secondSeededUserCanAuthenticate() throws Exception { mvc.perform(get("/api/v1/products").with(httpBasic("userb","pwd456"))).andExpect(status().isOk()); }
}
