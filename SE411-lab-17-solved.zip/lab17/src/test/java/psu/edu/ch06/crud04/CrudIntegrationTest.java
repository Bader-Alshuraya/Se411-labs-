package psu.edu.ch06.crud04;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.http.MediaType;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.httpBasic;
@SpringBootTest @AutoConfigureMockMvc @ActiveProfiles("test")
class CrudIntegrationTest {
 @Autowired MockMvc mvc;
 @Test void allFiveOperationsAndMissingRecords() throws Exception {
  String path="/api/v1/products";
  mvc.perform(get(path).with(httpBasic("usera","pwd123"))).andExpect(status().isOk()).andExpect(jsonPath("$[0].name").value("3d printer"));
  String location=mvc.perform(post(path).with(httpBasic("usera","pwd123")).contentType(MediaType.APPLICATION_JSON)
   .content("{\"name\":\"Test product\",\"description\":\"Created by test\",\"price\":12.50}"))
   .andExpect(status().isCreated()).andReturn().getResponse().getHeader("Location");
  org.junit.jupiter.api.Assertions.assertNotNull(location);
  org.junit.jupiter.api.Assertions.assertFalse(location.endsWith("null"));
  mvc.perform(get(location).with(httpBasic("usera","pwd123"))).andExpect(status().isOk()).andExpect(jsonPath("$.name").value("Test product"));
  mvc.perform(put(location).with(httpBasic("usera","pwd123")).contentType(MediaType.APPLICATION_JSON)
   .content("{\"name\":\"Updated product\",\"description\":\"Updated\",\"price\":20.25}"))
   .andExpect(status().isNoContent());
  mvc.perform(get(location).with(httpBasic("usera","pwd123"))).andExpect(jsonPath("$.price").value(20.25));
  mvc.perform(delete(location).with(httpBasic("usera","pwd123"))).andExpect(status().isNoContent());
  mvc.perform(get(location).with(httpBasic("usera","pwd123"))).andExpect(status().isNotFound());
  mvc.perform(put(location).with(httpBasic("usera","pwd123")).contentType(MediaType.APPLICATION_JSON).content("{\"name\":\"Missing product\",\"price\":1}"))
   .andExpect(status().isNotFound());
  mvc.perform(delete(location).with(httpBasic("usera","pwd123"))).andExpect(status().isNotFound());
 }
}
